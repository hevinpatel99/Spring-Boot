package com.organizationServices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrganizationServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
